import { BrowserRouter as Router, Routes, Route } from 'react-router-dom';
import Header from './components/Header';
import InfoSection from './components/InfoSection';
import OurSection from './components/Our';
import Rules from './components/Rules';
import Tariff from './components/Tariff';
import FAQ from './components/FAQ';
import Footer from './components/Footer';
import SecondPageHead from './pages/SecondPage';
import './components/style.css';

function App() {
  return (
    <Router>
      <div className="App">
        <Routes>
          <Route path="/" element={
            <>
              <Header />
              <InfoSection />
              <OurSection />
              <Rules />
              <Tariff />
              <FAQ />
              <Footer />
            </>
          } />
          <Route path="/second" element={<SecondPageHead />} />
        </Routes>
      </div>
    </Router>
  );
}

export default App;