import React, { useState } from 'react';
import { Link } from 'react-router-dom';
import './style-second.css';

function SecondPageHead() {
  const [selectedClasses, setSelectedClasses] = useState({
    economy: false,
    comfort: false,
    business: false,
    premium: false,
  });

  const classTranslation = {
    economy: 'Эконом',
    comfort: 'Комфорт',
    business: 'Бизнес',
    premium: 'Премиум',
  };

  const originalCars = [
    { 
      id: 1, 
      name: 'Lada Granta', 
      class: 'economy', 
      img: '../img/granta.png',
      description: 'ЛУЧШАЯ МАШИНА В МИРЕЁ',
      specifications: {
        capacity: '50 литров',
        power: '90 л.с.',
        seats: '5 мест',
        transmission: 'Механическая'
      }
    },
    { 
      id: 2, 
      name: 'Lada Vesta', 
      class: 'economy', 
      img: '../img/vesta.png',
      description: 'Lada Vesta – это седан с современным дизайном, просторным салоном и улучшенной шумоизоляцией, обеспечивающий комфортное вождение для всей семьи.',
      specifications: {
        capacity: '55 литров',
        power: '106 л.с.',
        seats: '5 мест',
        transmission: 'Автоматическая'
      }
    },
    { 
      id: 3, 
      name: 'Lada Largus', 
      class: 'economy', 
      img: '../img/largus.png',
      description: 'Lada Largus – универсал с просторным багажником и салоном, идеально подходит для семейных поездок и для тех, кто нуждается в большом объеме для перевозки вещей.',
      specifications: {
        capacity: '60 литров',
        power: '105 л.с.',
        seats: '7 мест',
        transmission: 'Механическая'
      }
    },
    { 
      id: 4, 
      name: 'Lada Kalina Cross', 
      class: 'economy', 
      img: '../img/kalina.png',
      description: 'Lada Kalina Cross – кроссовер с повышенной проходимостью, готовый справиться с легким бездорожьем и идеален для активных городских жителей.',
      specifications: {
        capacity: '50 литров',
        power: '106 л.с.',
        seats: '5 мест',
        transmission: 'Механическая'
      }
    },
    { 
      id: 5, 
      name: 'Kia K5', 
      class: 'comfort', 
      img: '../img/kiak5.png',
      description: 'Kia K5 – стильный и комфортный седан с хорошей динамикой, современными технологиями и комфортным салоном, идеально подходит для деловых поездок и семейных путешествий.',
      specifications: {
        capacity: '60 литров',
        power: '150 л.с.',
        seats: '5 мест',
        transmission: 'Автоматическая'
      }
    },
    { 
      id: 6, 
      name: 'Skoda Octavia', 
      class: 'comfort', 
      img: '../img/octavia2.png',
      description: 'Skoda Octavia – один из самых популярных автомобилей среднего класса с хорошими характеристиками по комфорту, безопасности и экономичности. Подходит для длительных поездок.',
      specifications: {
        capacity: '55 литров',
        power: '150 л.с.',
        seats: '5 мест',
        transmission: 'Механическая'
      }
    },
    { 
      id: 7, 
      name: 'Changan UNI-V', 
      class: 'business', 
      img: '../img/changan.png',
      description: 'Changan UNI-V – современный кроссовер бизнес-класса с передовыми технологиями и роскошным интерьером, предлагающий высокое качество и комфорт на дорогах.',
      specifications: {
        capacity: '65 литров',
        power: '200 л.с.',
        seats: '5 мест',
        transmission: 'Автоматическая'
      }
    },
    { 
      id: 8, 
      name: 'Geely Coolray', 
      class: 'business', 
      img: '../img/coolray.png',
      description: 'Geely Coolray – компактный кроссовер с мощным двигателем и современным дизайном, обеспечивающий высокий уровень комфорта и безопасности для водителя и пассажиров.',
      specifications: {
        capacity: '55 литров',
        power: '177 л.с.',
        seats: '5 мест',
        transmission: 'Автоматическая'
      }
    },
  ];
  

  const [filteredCars, setFilteredCars] = useState(originalCars);

  const handleCheckboxChange = (event) => {
    const { name, checked } = event.target;
    setSelectedClasses((prevState) => ({
      ...prevState,
      [name]: checked,
    }));
  };

  const filterCars = () => {
    const selectedClassesArray = Object.keys(selectedClasses).filter((key) => selectedClasses[key]);

    if (selectedClassesArray.length === 0) {
      setFilteredCars(originalCars);
    } else {
      const filtered = originalCars.filter((car) =>
        selectedClassesArray.includes(car.class) 
      );
      setFilteredCars(filtered);
    }
  };

  const [isDarkMode, setIsDarkMode] = useState(false);
  const [isMenuOpen, setIsMenuOpen] = useState(false);
  
  // Функция для переключения темы
  const toggleTheme = (theme) => {
    if (theme === 'dark') {
      setIsDarkMode(true);
      document.body.classList.add('dark-mode');
      document.body.classList.remove('light-mode');
    } else {
      setIsDarkMode(false);
      document.body.classList.add('light-mode');
      document.body.classList.remove('dark-mode');
    }
  };

  const toggleMenu = () => {
    setIsMenuOpen(!isMenuOpen);
  };

  const [isModalOpen, setIsModalOpen] = useState(false);
  const [currentCar, setCurrentCar] = useState(null);

  const openModal = (car) => {
    setCurrentCar(car);
    setIsModalOpen(true);
  };

  const closeModal = () => {
    setIsModalOpen(false);
    setCurrentCar(null);
  };

  return (
    <>
      <header>
        <div className="header-container">
          <Link to="/">
            <img src="./img/svg/Logo.svg" alt="Логотип ZipCar" />
          </Link>
          <button className="menu-toggle" onClick={toggleMenu} aria-label="Открыть меню">
            <span></span>
            <span></span>
            <span></span>
          </button>
          <div className={`header-right ${isMenuOpen ? 'menu-open' : ''}`}>
            <nav className="nav-list">
              <ul className="site-navigation">
                <li className="site-navigation-item">
                  <Link to="/"><a href="#Our" className="anchor-link">О нас</a></Link>
                </li>
                <li className="site-navigation-item">
                  <Link to="/"><a href="#rules" className="anchor-link">Правила</a></Link>
                </li>
                <li className="site-navigation-item">
                  <a className="anchor-link">Тарифы</a>
                </li>
                <li className="site-navigation-item">
                  <Link to="/"><a href="#FAQ" className="anchor-link">Помощь</a></Link>
                </li>
                <li className="site-navigation-item">
                  +7 (999) 162-79-25
                </li>
              </ul>
            </nav>
            <ul className="themes">
              <li>
                <button
                  className={`theme-button ${!isDarkMode ? 'active' : ''} theme-button-light`}
                  type="button"
                  onClick={() => toggleTheme('light')}
                >
                  Светлая
                </button>
              </li>
              <li>
                <button
                  className={`theme-button ${isDarkMode ? 'active' : ''} theme-button-dark`}
                  type="button"
                  onClick={() => toggleTheme('dark')}
                >
                  Темная
                </button>
              </li>
            </ul>
          </div>
        </div>
      </header>

      {/* Новый блок */}
      <section className="rental-section">
        <h2>Наш автопарк</h2>
        <div className="rental-form">
          <p>Выберите класс автомобиля:</p>
          <div className="rental-options">
            <label className="checkbox-wrapper">
              <input
                type="checkbox"
                id="cbx-economy"  
                name="economy"
                checked={selectedClasses.economy}
                onChange={handleCheckboxChange}
              />
              <label htmlFor="cbx-economy" className="check">
                <svg width="18px" height="18px" viewBox="0 0 18 18">
                  <path d="M1,9 L1,3.5 C1,2 2,1 3.5,1 L14.5,1 C16,1 17,2 17,3.5 L17,14.5 C17,16 16,17 14.5,17 L3.5,17 C2,17 1,16 1,14.5 L1,9 Z"></path>
                  <polyline points="1 9 7 14 15 4"></polyline>
                </svg>
              </label>
              Эконом
            </label>
            <label className="checkbox-wrapper">
              <input
                type="checkbox"
                id="cbx-comfort"  
                name="comfort"
                checked={selectedClasses.comfort}
                onChange={handleCheckboxChange}
              />
              <label htmlFor="cbx-comfort" className="check">
                <svg width="18px" height="18px" viewBox="0 0 18 18">
                  <path d="M1,9 L1,3.5 C1,2 2,1 3.5,1 L14.5,1 C16,1 17,2 17,3.5 L17,14.5 C17,16 16,17 14.5,17 L3.5,17 C2,17 1,16 1,14.5 L1,9 Z"></path>
                  <polyline points="1 9 7 14 15 4"></polyline>
                </svg>
              </label>
              Комфорт
            </label>
            <label className="checkbox-wrapper">
              <input
                type="checkbox"
                id="cbx-business"  
                name="business"
                checked={selectedClasses.business}
                onChange={handleCheckboxChange}
              />
              <label htmlFor="cbx-business" className="check">
                <svg width="18px" height="18px" viewBox="0 0 18 18">
                  <path d="M1,9 L1,3.5 C1,2 2,1 3.5,1 L14.5,1 C16,1 17,2 17,3.5 L17,14.5 C17,16 16,17 14.5,17 L3.5,17 C2,17 1,16 1,14.5 L1,9 Z"></path>
                  <polyline points="1 9 7 14 15 4"></polyline>
                </svg>
              </label>
              Бизнес
            </label>
            <label className="checkbox-wrapper">
              <input
                type="checkbox"
                id="cbx-premium" 
                name="premium"
                checked={selectedClasses.premium}
                onChange={handleCheckboxChange}
              />
            </label>
          </div>
          <button className="rental-button" onClick={filterCars}>
            Посмотреть
          </button>
        </div>
      </section>

      <section className="cars">
        {filteredCars.map((car) => (
          <div key={car.id} className="card-all">
            <img src={car.img} alt={car.name} className="cards-img" />
            <p>Марка автомобиля: {car.name}</p>
            <p>Класс: {classTranslation[car.class]}</p>
            <p className='about-car'><b>Описание: </b>{car.description}</p>
            <button className='compare' onClick={() => openModal(car)}>
              Побробнее
            </button>
          </div>
        ))}
      </section>

      {isModalOpen && currentCar && (
        <div className="modal-overlay">
          <div className="modal-content">
            <h2>{currentCar.name}</h2>
            <img src={currentCar.img} alt={currentCar.name} className="modal-img" />
            <p><b>Класс:</b> {classTranslation[currentCar.class]}</p>
            <p><b>Объем бака:</b> {currentCar.specifications.capacity}</p>
            <p><b>Мощность:</b> {currentCar.specifications.power}</p>
            <p><b>Количество мест:</b> {currentCar.specifications.seats}</p>
            <p><b>Трансмиссия:</b> {currentCar.specifications.transmission}</p>
            <p><b>Описание:</b> {currentCar.description}</p>
            <button onClick={closeModal} className="close-modal-btn">
              Закрыть
            </button>
          </div>
        </div>
      )}

      <div className='end'>
        <Link to='/'><button className='back-btn'> Назад на главную </button></Link>
        <h3 className='end-screen'>
          Автопарк еще будет пополнятся!
        </h3>
      </div>
    </>
  );
}

export default SecondPageHead;
