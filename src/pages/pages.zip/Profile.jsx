import { useEffect, useMemo, useState } from "react";
import { Link, useNavigate } from "react-router-dom";
import {
  profile,
  updateProfile,
  changePassword,
  uploadAvatar,
  sendEmailCode,
  verifyEmailCode,
} from "../api/auth";

export default function ProfilePage() {
  const nav = useNavigate();
  const [user, setUser] = useState(null);
  const [saving, setSaving] = useState(false);
  const [err, setErr] = useState("");
  const [ok, setOk] = useState("");

  const [name, setName] = useState("");
  const [email, setEmail] = useState("");
  const [dob, setDob] = useState("");
  const [code, setCode] = useState("");

  const [showPass, setShowPass] = useState(false);
  const [currentPassword, setCurrentPassword] = useState("");
  const [newPassword, setNewPassword] = useState("");
  const [newPassword2, setNewPassword2] = useState("");

  const [sendingCode, setSendingCode] = useState(false);
  const [verifyingCode, setVerifyingCode] = useState(false);

  const avatarUrl = useMemo(() => {
    if (!user?.avatar_path) return null;
    if (String(user.avatar_path).startsWith("http")) return user.avatar_path;
    return `http://localhost:8000/storage/${user.avatar_path}`;
  }, [user]);

  useEffect(() => {
    (async () => {
      try {
        const u = await profile();
        setUser(u);
        setName(u.name || "");
        setEmail(u.email || "");
        setDob(u.date_of_birth || "");
      } catch (e) {
        if (e?.response?.status === 401) nav("/login");
        else setErr("Не удалось загрузить профиль");
      }
    })();
  }, [nav]);

  const saveProfile = async (e) => {
    e.preventDefault();
    setErr("");
    setOk("");
    setSaving(true);

    try {
      const u = await updateProfile({
        name,
        email,
        date_of_birth: dob || null,
      });

      setUser(u);
      setName(u.name || "");
      setEmail(u.email || "");
      setDob(u.date_of_birth || "");
      setOk("Профиль обновлён");
    } catch (e2) {
      const msg =
        e2?.response?.data?.message ||
        (e2?.response?.data?.errors
          ? Object.values(e2.response.data.errors).flat().join("\n")
          : null) ||
        "Ошибка сохранения";
      setErr(msg);
    } finally {
      setSaving(false);
    }
  };

  const savePassword = async (e) => {
    e.preventDefault();
    setErr("");
    setOk("");

    if (newPassword !== newPassword2) {
      setErr("Новый пароль и подтверждение не совпадают");
      return;
    }

    setSaving(true);

    try {
      await changePassword({
        current_password: currentPassword,
        password: newPassword,
        password_confirmation: newPassword2,
      });

      setCurrentPassword("");
      setNewPassword("");
      setNewPassword2("");
      setOk("Пароль изменён");
    } catch (e2) {
      const msg =
        e2?.response?.data?.message ||
        (e2?.response?.data?.errors
          ? Object.values(e2.response.data.errors).flat().join("\n")
          : null) ||
        "Ошибка смены пароля";
      setErr(msg);
    } finally {
      setSaving(false);
    }
  };

  const onAvatar = async (e) => {
    const file = e.target.files?.[0];
    if (!file) return;

    setErr("");
    setOk("");
    setSaving(true);

    try {
      const u = await uploadAvatar(file);
      setUser(u);
      setOk("Аватар обновлён");
    } catch (e2) {
      const msg =
        e2?.response?.data?.message ||
        (e2?.response?.data?.errors
          ? Object.values(e2.response.data.errors).flat().join("\n")
          : null) ||
        "Ошибка загрузки аватара";
      setErr(msg);
    } finally {
      setSaving(false);
      e.target.value = "";
    }
  };

  const handleSendCode = async () => {
    if (sendingCode) return;

    setErr("");
    setOk("");
    setSendingCode(true);

    try {
      const res = await sendEmailCode();

      if (res?.debug_code) {
        setCode(String(res.debug_code));
        setOk(`SMTP недоступен. Код для входа: ${res.debug_code}`);
      } else {
        setOk(res?.message || "Код подтверждения отправлен на вашу почту.");
      }
    } catch (e2) {
      setErr(
        e2?.response?.data?.message ||
          "Не удалось отправить код подтверждения"
      );
    } finally {
      setSendingCode(false);
    }
  };

  const handleVerifyCode = async () => {
    if (verifyingCode || code.length !== 6) return;

    setErr("");
    setOk("");
    setVerifyingCode(true);

    try {
      const u = await verifyEmailCode(code);
      setUser(u);
      setCode("");
      setOk("Почта успешно подтверждена! ✅");
    } catch (e2) {
      setErr(e2?.response?.data?.message || "Неверный код");
    } finally {
      setVerifyingCode(false);
    }
  };

  const formatDate = (dateString) => {
    if (!dateString) return "Не указана";

    try {
      const date = new Date(dateString);
      return date.toLocaleDateString("ru-RU", {
        day: "numeric",
        month: "long",
        year: "numeric",
      });
    } catch {
      return dateString;
    }
  };

  if (!user) {
    return (
      <div
        style={{
          display: "flex",
          justifyContent: "center",
          alignItems: "center",
          minHeight: "400px",
          fontSize: "18px",
          color: "#64748b",
        }}
      >
        Загрузка профиля...
      </div>
    );
  }

  return (
    <div className="profile-container">
      <style>{`
        * {
          margin: 0;
          padding: 0;
          box-sizing: border-box;
          font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, Oxygen, Ubuntu, sans-serif;
        }

        .profile-container {
          max-width: 1200px;
          margin: 0 auto;
          padding: 20px;
          min-height: 100vh;
          background: #f8fafc;
        }

        .header {
          background: white;
          border-radius: 16px;
          padding: 24px;
          margin-bottom: 24px;
          box-shadow: 0 2px 8px rgba(0, 0, 0, 0.06);
        }

        .header-top {
          display: flex;
          flex-direction: column;
          gap: 16px;
          margin-bottom: 16px;
        }

        @media (min-width: 768px) {
          .header-top {
            flex-direction: row;
            justify-content: space-between;
            align-items: center;
          }
        }

        .title {
          font-size: 28px;
          font-weight: 700;
          color: #1e293b;
          margin: 0;
        }

        .nav-links {
          display: flex;
          gap: 12px;
          flex-wrap: wrap;
        }

        .nav-button {
          padding: 10px 20px;
          background: white;
          border: 2px solid #e2e8f0;
          border-radius: 10px;
          color: #475569;
          text-decoration: none;
          font-weight: 500;
          transition: all 0.2s;
          white-space: nowrap;
          text-align: center;
          font-size: 14px;
        }

        .nav-button:hover {
          background: #f1f5f9;
          border-color: #cbd5e1;
          transform: translateY(-1px);
        }

        .nav-button.primary {
          background: #3b82f6;
          color: white;
          border-color: #3b82f6;
        }

        .nav-button.primary:hover {
          background: #2563eb;
          border-color: #2563eb;
        }

        .message {
          padding: 14px 20px;
          border-radius: 10px;
          margin: 16px 0;
          font-size: 14px;
          display: flex;
          align-items: center;
          gap: 10px;
          animation: slideIn 0.3s ease;
          white-space: pre-line;
        }

        @keyframes slideIn {
          from {
            opacity: 0;
            transform: translateY(-10px);
          }
          to {
            opacity: 1;
            transform: translateY(0);
          }
        }

        .error {
          background: #fee2e2;
          border: 1px solid #fecaca;
          color: #dc2626;
        }

        .success {
          background: #d1fae5;
          border: 1px solid #a7f3d0;
          color: #065f46;
        }

        .profile-content {
          display: grid;
          gap: 24px;
        }

        @media (min-width: 992px) {
          .profile-content {
            grid-template-columns: 280px 1fr;
          }
        }

        .sidebar {
          background: white;
          border-radius: 16px;
          padding: 24px;
          box-shadow: 0 2px 8px rgba(0, 0, 0, 0.06);
          display: flex;
          flex-direction: column;
          align-items: center;
          gap: 20px;
        }

        .avatar-container {
          width: 200px;
          height: 200px;
          border-radius: 16px;
          overflow: hidden;
          position: relative;
          border: 3px solid #e2e8f0;
          transition: all 0.3s ease;
        }

        .avatar-container:hover {
          border-color: #3b82f6;
          transform: scale(1.02);
        }

        .avatar-image {
          width: 100%;
          height: 100%;
          object-fit: cover;
        }

        .avatar-placeholder {
          width: 100%;
          height: 100%;
          display: flex;
          flex-direction: column;
          align-items: center;
          justify-content: center;
          background: #f1f5f9;
          color: #94a3b8;
          font-size: 14px;
        }

        .avatar-placeholder-icon {
          font-size: 48px;
          margin-bottom: 8px;
        }

        .avatar-upload {
          width: 100%;
        }

        .file-input-wrapper {
          position: relative;
          overflow: hidden;
          width: 100%;
        }

        .file-input {
          position: absolute;
          left: 0;
          top: 0;
          opacity: 0;
          width: 100%;
          height: 100%;
          cursor: pointer;
        }

        .upload-button {
          width: 100%;
          padding: 12px;
          background: #f8fafc;
          border: 2px dashed #cbd5e1;
          border-radius: 10px;
          color: #475569;
          text-align: center;
          cursor: pointer;
          transition: all 0.2s;
          font-weight: 500;
          display: block;
        }

        .upload-button:hover {
          background: #e2e8f0;
          border-color: #94a3b8;
        }

        .user-info {
          background: white;
          border-radius: 16px;
          padding: 24px;
          box-shadow: 0 2px 8px rgba(0, 0, 0, 0.06);
          display: grid;
          gap: 24px;
        }

        .info-section {
          background: #f8fafc;
          border-radius: 12px;
          padding: 24px;
        }

        .section-title {
          font-size: 20px;
          font-weight: 600;
          color: #1e293b;
          margin-bottom: 20px;
          display: flex;
          align-items: center;
          gap: 10px;
        }

        .section-title::before {
          content: "•";
          color: #3b82f6;
          font-size: 24px;
        }

        .form-grid {
          display: grid;
          gap: 20px;
        }

        @media (min-width: 768px) {
          .form-grid {
            grid-template-columns: 1fr 1fr;
          }
        }

        .form-group {
          display: flex;
          flex-direction: column;
          gap: 8px;
        }

        .form-label {
          font-size: 14px;
          font-weight: 500;
          color: #475569;
          display: flex;
          align-items: center;
          gap: 6px;
        }

        .form-label::before {
          content: "▸";
          color: #94a3b8;
          font-size: 12px;
        }

        .form-input {
          padding: 12px 16px;
          border: 2px solid #e2e8f0;
          border-radius: 10px;
          font-size: 15px;
          color: #1e293b;
          transition: all 0.2s;
          background: white;
        }

        .form-input:focus {
          outline: none;
          border-color: #3b82f6;
          box-shadow: 0 0 0 3px rgba(59, 130, 246, 0.1);
        }

        .form-input:disabled {
          background: #f1f5f9;
          color: #94a3b8;
          cursor: not-allowed;
        }

        .submit-button {
          padding: 14px 28px;
          background: #3b82f6;
          color: white;
          border: none;
          border-radius: 10px;
          font-size: 16px;
          font-weight: 600;
          cursor: pointer;
          transition: all 0.2s;
          width: 100%;
          margin-top: 10px;
        }

        .submit-button:hover:not(:disabled) {
          background: #2563eb;
          transform: translateY(-2px);
          box-shadow: 0 4px 12px rgba(37, 99, 235, 0.2);
        }

        .submit-button:disabled {
          background: #cbd5e1;
          cursor: not-allowed;
          transform: none;
        }

        .toggle-button {
          padding: 12px 20px;
          background: #f1f5f9;
          border: 2px solid #e2e8f0;
          border-radius: 10px;
          color: #475569;
          font-weight: 500;
          cursor: pointer;
          transition: all 0.2s;
          display: flex;
          align-items: center;
          justify-content: center;
          gap: 8px;
          width: 100%;
        }

        .toggle-button:hover {
          background: #e2e8f0;
          border-color: #cbd5e1;
        }

        .toggle-icon {
          font-size: 18px;
        }

        .password-fields {
          display: grid;
          gap: 20px;
          margin-top: 20px;
          animation: fadeIn 0.3s ease;
        }

        @keyframes fadeIn {
          from {
            opacity: 0;
            transform: translateY(-10px);
          }
          to {
            opacity: 1;
            transform: translateY(0);
          }
        }

        .verification-section {
          background: #fef3c7;
          border-radius: 12px;
          padding: 24px;
          border: 2px solid #fde68a;
        }

        .verification-status {
          display: flex;
          align-items: center;
          gap: 10px;
          margin-bottom: 20px;
          flex-wrap: wrap;
        }

        .status-badge {
          padding: 6px 14px;
          border-radius: 20px;
          font-size: 13px;
          font-weight: 600;
          text-transform: uppercase;
          letter-spacing: 0.5px;
        }

        .status-verified {
          background: #d1fae5;
          color: #065f46;
        }

        .status-pending {
          background: #fee2e2;
          color: #dc2626;
        }

        .code-input-group {
          display: flex;
          gap: 10px;
          margin-top: 16px;
          flex-wrap: wrap;
        }

        .code-input {
          flex: 1;
          min-width: 220px;
          padding: 12px 16px;
          border: 2px solid #e2e8f0;
          border-radius: 10px;
          font-size: 16px;
          text-align: center;
          letter-spacing: 4px;
          font-weight: 600;
        }

        .code-input:focus {
          outline: none;
          border-color: #f59e0b;
          box-shadow: 0 0 0 3px rgba(245, 158, 11, 0.12);
        }

        .code-button {
          padding: 12px 24px;
          background: #f59e0b;
          color: white;
          border: none;
          border-radius: 10px;
          font-weight: 600;
          cursor: pointer;
          transition: all 0.2s;
          white-space: nowrap;
        }

        .code-button:hover:not(:disabled) {
          background: #d97706;
          transform: translateY(-1px);
        }

        .code-button:disabled {
          background: #cbd5e1;
          cursor: not-allowed;
        }

        .send-code-button {
          padding: 12px 24px;
          background: white;
          border: 2px solid #f59e0b;
          color: #d97706;
          border-radius: 10px;
          font-weight: 600;
          cursor: pointer;
          transition: all 0.2s;
          width: 100%;
        }

        .send-code-button:hover:not(:disabled) {
          background: #fef3c7;
        }

        .send-code-button:disabled {
          opacity: 0.7;
          cursor: not-allowed;
        }

        .hint-text {
          font-size: 13px;
          color: #64748b;
          line-height: 1.5;
          margin-top: 8px;
        }

        .stats-grid {
          display: grid;
          grid-template-columns: repeat(auto-fit, minmax(150px, 1fr));
          gap: 16px;
          margin-top: 16px;
          width: 100%;
        }

        .stat-card {
          background: white;
          border-radius: 12px;
          padding: 20px;
          text-align: center;
          border: 1px solid #e2e8f0;
        }

        .stat-value {
          font-size: 24px;
          font-weight: 700;
          color: #1e293b;
          margin-bottom: 4px;
          word-break: break-word;
        }

        .stat-label {
          font-size: 13px;
          color: #64748b;
          text-transform: uppercase;
          letter-spacing: 0.5px;
        }

        .mobile-only {
          display: block;
        }

        .desktop-only {
          display: none;
        }

        @media (min-width: 768px) {
          .mobile-only {
            display: none;
          }
          .desktop-only {
            display: block;
          }
        }
      `}</style>

      <header className="header">
        <div className="header-top">
          <h1 className="title">Мой профиль</h1>
          <div className="nav-links">
            <Link to="/" className="nav-button">
              ← На главную
            </Link>
            <Link to="/my-bookings" className="nav-button primary">
              Мои поездки
            </Link>
            <Link
              to="/notifications"
              className="all-cars nav-button"
              style={{ margin: 0 }}
            >
              Уведомления
            </Link>
          </div>
        </div>
        <div className="desktop-only">
          <p style={{ color: "#64748b", fontSize: "15px" }}>
            Управление личными данными и настройками аккаунта
          </p>
        </div>
      </header>

      {err && (
        <div className="message error">
          <span style={{ fontSize: "20px" }}>⚠️</span>
          <span>{err}</span>
        </div>
      )}

      {ok && (
        <div className="message success">
          <span style={{ fontSize: "20px" }}>✅</span>
          <span>{ok}</span>
        </div>
      )}

      <div className="profile-content">
        <div className="sidebar">
          <div className="avatar-container">
            {avatarUrl ? (
              <img src={avatarUrl} alt="Аватар" className="avatar-image" />
            ) : (
              <div className="avatar-placeholder">
                <div className="avatar-placeholder-icon">👤</div>
                <span>Нет фото</span>
              </div>
            )}
          </div>

          <div className="avatar-upload">
            <div className="file-input-wrapper">
              <input
                type="file"
                accept="image/*"
                onChange={onAvatar}
                disabled={saving}
                className="file-input"
                id="avatarUpload"
              />
              <label htmlFor="avatarUpload" className="upload-button">
                {saving ? "Загрузка..." : "Сменить аватар"}
              </label>
            </div>
          </div>

          <div className="stats-grid">
            <div className="stat-card">
              <div className="stat-value">{user.total_bookings || 0}</div>
              <div className="stat-label">Поездок</div>
            </div>
            <div className="stat-card">
              <div className="stat-value">{formatDate(user.created_at)}</div>
              <div className="stat-label">Дата регистрации</div>
            </div>
          </div>
        </div>

        <div className="user-info">
          <div className="info-section">
            <h3 className="section-title">Личные данные</h3>
            <form onSubmit={saveProfile} className="form-grid">
              <div className="form-group">
                <label className="form-label">Имя</label>
                <input
                  type="text"
                  value={name}
                  onChange={(e) => setName(e.target.value)}
                  className="form-input"
                  placeholder="Введите ваше имя"
                  disabled={saving}
                />
              </div>

              <div className="form-group">
                <label className="form-label">Электронная почта</label>
                <input
                  type="email"
                  value={email}
                  onChange={(e) => setEmail(e.target.value)}
                  className="form-input"
                  placeholder="email@example.com"
                  disabled={saving}
                />
              </div>

              <div className="form-group">
                <label className="form-label">Дата рождения</label>
                <input
                  type="date"
                  value={dob}
                  onChange={(e) => setDob(e.target.value)}
                  className="form-input"
                  disabled={saving}
                />
              </div>

              <div className="form-group" style={{ gridColumn: "span 2" }}>
                <button
                  type="submit"
                  className="submit-button"
                  disabled={saving}
                >
                  {saving ? "Сохранение..." : "Сохранить изменения"}
                </button>
              </div>
            </form>
          </div>

          <div className="info-section">
            <h3 className="section-title">Безопасность</h3>
            <div className="hint-text">
              Текущий пароль показать нельзя (он хранится в зашифрованном
              виде). Вы можете изменить пароль, указав текущий и новый пароли.
            </div>

            <button
              type="button"
              onClick={() => setShowPass((v) => !v)}
              className="toggle-button"
            >
              <span className="toggle-icon">{showPass ? "▼" : "▶"}</span>
              {showPass ? "Скрыть настройки пароля" : "Изменить пароль"}
            </button>

            {showPass && (
              <form onSubmit={savePassword} className="password-fields">
                <div className="form-grid">
                  <div className="form-group">
                    <label className="form-label">Текущий пароль</label>
                    <input
                      type="password"
                      value={currentPassword}
                      onChange={(e) => setCurrentPassword(e.target.value)}
                      className="form-input"
                      placeholder="••••••••"
                      disabled={saving}
                    />
                  </div>

                  <div className="form-group">
                    <label className="form-label">Новый пароль</label>
                    <input
                      type="password"
                      value={newPassword}
                      onChange={(e) => setNewPassword(e.target.value)}
                      className="form-input"
                      placeholder="••••••••"
                      disabled={saving}
                    />
                  </div>

                  <div className="form-group">
                    <label className="form-label">Повторите пароль</label>
                    <input
                      type="password"
                      value={newPassword2}
                      onChange={(e) => setNewPassword2(e.target.value)}
                      className="form-input"
                      placeholder="••••••••"
                      disabled={saving}
                    />
                  </div>
                </div>

                <button
                  type="submit"
                  className="submit-button"
                  disabled={saving}
                >
                  {saving ? "Сохранение..." : "Обновить пароль"}
                </button>
              </form>
            )}
          </div>

          <div className="verification-section">
            <div className="verification-status">
              <h3 className="section-title" style={{ margin: 0 }}>
                Подтверждение аккаунта
              </h3>
              <span
                className={`status-badge ${
                  user.email_verified_at ? "status-verified" : "status-pending"
                }`}
              >
                {user.email_verified_at ? "Подтверждён" : "Не подтверждён"}
              </span>
            </div>

            {!user.email_verified_at && (
              <>
                <p className="hint-text" style={{ color: "#92400e" }}>
                  Подтвердите вашу электронную почту для полного доступа ко всем
                  функциям
                </p>

                <button
                  type="button"
                  onClick={handleSendCode}
                  disabled={sendingCode || saving}
                  className="send-code-button"
                >
                  {sendingCode
                    ? "Отправка..."
                    : "Отправить код подтверждения"}
                </button>

                <div className="code-input-group">
                  <input
                    type="text"
                    value={code}
                    onChange={(e) =>
                      setCode(e.target.value.replace(/\D/g, "").slice(0, 6))
                    }
                    placeholder="Введите 6-значный код"
                    className="code-input"
                    maxLength="6"
                    pattern="[0-9]*"
                    inputMode="numeric"
                  />
                  <button
                    type="button"
                    onClick={handleVerifyCode}
                    disabled={saving || verifyingCode || code.length !== 6}
                    className="code-button"
                  >
                    {verifyingCode ? "Проверка..." : "Подтвердить"}
                  </button>
                </div>
              </>
            )}

            {user.email_verified_at && (
              <div
                style={{
                  background: "#d1fae5",
                  padding: "16px",
                  borderRadius: "8px",
                  textAlign: "center",
                  marginTop: "16px",
                }}
              >
                <span style={{ color: "#065f46", fontWeight: "500" }}>
                  ✅ Ваша почта подтверждена
                </span>
              </div>
            )}
          </div>
        </div>
      </div>
    </div>
  );
}