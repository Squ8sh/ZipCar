import { useEffect, useState } from "react";
import { Link, useNavigate } from "react-router-dom";
import { myBookings, me, cancelMyBooking, completeMyBooking } from "../api/auth";

const STATUS_LABEL = {
  booked: "Запланирована",
  active: "В поездке",
  completed: "Завершена",
  canceled: "Отменена",
};

const STATUS_COLOR = {
  booked: "#f59e0b",
  active: "#2563eb",
  completed: "#16a34a",
  canceled: "#dc2626",
};

const TARIFF_LABEL = {
  minute: "Поминутно",
  hour: "Почасово",
  day: "Посуточно",
  open: "До завершения",
};

const CLASS_LABEL = {
  economy: "Эконом",
  comfort: "Комфорт",
  business: "Бизнес",
  premium: "Премиум",
};

function fmtDate(date) {
  if (!date) return "—";
  return new Date(date).toLocaleString("ru-RU", {
    day: "2-digit",
    month: "2-digit",
    year: "numeric",
    hour: "2-digit",
    minute: "2-digit",
  });
}

function fmtMoney(value) {
  return new Intl.NumberFormat("ru-RU").format(Number(value || 0));
}

export default function MyBookingsPage() {
  const nav = useNavigate();
  const [data, setData] = useState(null);
  const [page, setPage] = useState(1);
  const [err, setErr] = useState("");
  const [loading, setLoading] = useState(false);
  const [busyId, setBusyId] = useState(null);
  const [expanded, setExpanded] = useState({});

  async function load() {
    setLoading(true);
    setErr("");
    try {
      await me();
      const res = await myBookings(page);
      setData(res);
    } catch (e) {
      if (e?.response?.status === 401) nav("/login");
      else setErr(e?.response?.data?.message || "Не удалось загрузить поездки");
    } finally {
      setLoading(false);
    }
  }

  useEffect(() => {
    load();
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [page]);

  function mergeBooking(updated) {
    setData((prev) => {
      if (!prev) return prev;
      return {
        ...prev,
        data: prev.data.map((x) => (x.id === updated.id ? { ...x, ...updated } : x)),
      };
    });
  }

  async function onCancel(b) {
    if (!window.confirm("Отменить это бронирование?")) return;
    setBusyId(b.id);
    setErr("");
    try {
      const updated = await cancelMyBooking(b.id);
      mergeBooking(updated);
      await load();
    } catch (e) {
      setErr(e?.response?.data?.message || "Не удалось отменить бронирование");
    } finally {
      setBusyId(null);
    }
  }

  async function onComplete(b) {
    if (!window.confirm("Завершить поездку сейчас?")) return;
    setBusyId(b.id);
    setErr("");
    try {
      const updated = await completeMyBooking(b.id);
      mergeBooking(updated);
      await load();
    } catch (e) {
      setErr(e?.response?.data?.message || "Не удалось завершить поездку");
    } finally {
      setBusyId(null);
    }
  }

  return (
    <div style={{ maxWidth: 1100, margin: "0 auto", padding: 20 }}>
      <h1 style={{ marginBottom: 10 }}>Мои поездки</h1>
      <div style={{ display: "flex", gap: 12, marginBottom: 18, flexWrap: "wrap" }}>
        <Link to="/second">Новая аренда</Link>
        <Link to="/notifications">Уведомления</Link>
        <Link to="/profile">Профиль</Link>
      </div>

      {err && (
        <div style={{ color: "#b91c1c", background: "#fee2e2", border: "1px solid #fecaca", borderRadius: 10, padding: 10, marginBottom: 14 }}>
          {err}
        </div>
      )}

      {loading && <div>Загрузка...</div>}

      {!loading && data && data.data.length === 0 && (
        <div style={{ padding: 20, border: "1px solid #e5e7eb", borderRadius: 12 }}>
          Пока нет поездок. Оформите первое бронирование в автопарке.
        </div>
      )}

      {!loading && data && data.data.length > 0 && (
        <>
          <div style={{ display: "grid", gap: 14 }}>
            {data.data.map((b) => {
              const isExpanded = !!expanded[b.id];
              const showFinish = b.status === "active" && b.can_finish;
              const showCancel = b.status === "booked" || b.status === "active";
              const statusColor = STATUS_COLOR[b.status] || "#6b7280";

              return (
                <div
                  key={b.id}
                  style={{
                    border: "1px solid #e5e7eb",
                    borderLeft: `5px solid ${statusColor}`,
                    borderRadius: 12,
                    padding: 14,
                    background: "#fff",
                  }}
                >
                  <div style={{ display: "flex", justifyContent: "space-between", gap: 12, flexWrap: "wrap" }}>
                    <div>
                      <h3 style={{ margin: 0 }}>{b.car?.name || `Авто #${b.car_id}`}</h3>
                      <div style={{ marginTop: 4, color: "#4b5563", fontSize: 14 }}>
                        Класс: {CLASS_LABEL[b.car?.class] || b.car?.class || "—"} · Госномер: {b.car?.plate_number || "—"}
                      </div>
                    </div>
                    <div style={{ fontWeight: 700, color: statusColor }}>
                      {STATUS_LABEL[b.status] || b.status}
                    </div>
                  </div>

                  <div style={{ marginTop: 10, display: "grid", gap: 6, color: "#374151" }}>
                    <div>Начало аренды: {fmtDate(b.start_at)}</div>
                    <div>Тариф: {TARIFF_LABEL[b.tariff_mode] || b.tariff_mode} {b.tariff_value ? `(${b.tariff_value})` : ""}</div>
                    <div>Текущая сумма: {fmtMoney(b.current_total_rub ?? b.final_price_rub ?? b.price_rub)} ₽</div>
                    {!b.ends_on_user_action && b.status === "active" && typeof b.minutes_to_end === "number" && b.minutes_to_end <= 10 && b.minutes_to_end >= 0 && (
                      <div style={{ color: "#b45309", fontWeight: 600 }}>
                        До конца аренды осталось {b.minutes_to_end} мин. Доступно завершение поездки.
                      </div>
                    )}
                    {!b.ends_on_user_action && b.status === "active" && typeof b.minutes_to_end === "number" && b.minutes_to_end < 0 && (
                      <div style={{ color: "#b91c1c", fontWeight: 600 }}>
                        Просрочка: {Math.abs(b.minutes_to_end)} мин. Штраф: {fmtMoney(b.current_penalty_rub)} ₽
                      </div>
                    )}
                  </div>

                  <div style={{ marginTop: 12, display: "flex", gap: 8, flexWrap: "wrap" }}>
                    {showCancel && (
                      <button onClick={() => onCancel(b)} disabled={busyId === b.id}>
                        {busyId === b.id ? "Обработка..." : "Отменить бронь"}
                      </button>
                    )}
                    {showFinish && (
                      <button onClick={() => onComplete(b)} disabled={busyId === b.id}>
                        {busyId === b.id ? "Обработка..." : "Завершить поездку"}
                      </button>
                    )}
                    <button onClick={() => setExpanded((prev) => ({ ...prev, [b.id]: !prev[b.id] }))}>
                      {isExpanded ? "Скрыть детали" : "Подробнее"}
                    </button>
                  </div>

                  {isExpanded && (
                    <div style={{ marginTop: 12, paddingTop: 10, borderTop: "1px dashed #d1d5db", display: "grid", gap: 6, color: "#1f2937" }}>
                      <div>Водитель: {b.driver_name}</div>
                      <div>Тип поездки: {b.ride_type === "intercity" ? "Межгород (+10%)" : "Город"}</div>
                      <div>Парковка: {b.parking_name || "—"}</div>
                      <div>Адрес парковки: {b.parking_address || "—"}</div>
                      <div>Плановое завершение: {fmtDate(b.planned_end_at)}</div>
                      <div>Фактическое завершение: {fmtDate(b.ended_at)}</div>
                      <div>Перепробег: {b.overtime_minutes || 0} мин</div>
                      <div>Штраф: {fmtMoney(b.overtime_penalty_rub || 0)} ₽</div>
                      <div>Финальная сумма: {fmtMoney(b.final_price_rub ?? b.current_total_rub ?? b.price_rub)} ₽</div>
                    </div>
                  )}
                </div>
              );
            })}
          </div>

          {data.last_page > 1 && (
            <div style={{ marginTop: 16, display: "flex", gap: 10, alignItems: "center" }}>
              <button disabled={!data.prev_page_url} onClick={() => setPage((p) => Math.max(1, p - 1))}>
                Назад
              </button>
              <span>
                Страница {data.current_page} из {data.last_page}
              </span>
              <button disabled={!data.next_page_url} onClick={() => setPage((p) => p + 1)}>
                Вперёд
              </button>
            </div>
          )}
        </>
      )}
    </div>
  );
}
