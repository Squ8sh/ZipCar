﻿import { useEffect, useState } from "react";
import { Link, useNavigate } from "react-router-dom";
import { me, getNotifications, markNotificationRead, notificationAction } from "../api/auth";

export default function NotificationsPage() {
  const nav = useNavigate();

  const [loadingAuth, setLoadingAuth] = useState(true);
  const [loading, setLoading] = useState(true);
  const [err, setErr] = useState("");
  const [data, setData] = useState(null);
  const [page, setPage] = useState(1);
  const [actionLoading, setActionLoading] = useState({});

  const load = async () => {
    setErr("");
    setLoading(true);
    try {
      const res = await getNotifications(page);
      setData(res);
    } catch (e) {
      setErr(e?.response?.data?.message || "Не удалось загрузить уведомления");
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    (async () => {
      try {
        const u = await me();
        if (!u) return nav("/login");
        setLoadingAuth(false);
      } catch {
        nav("/login");
      }
    })();
  }, [nav]);

  useEffect(() => {
    if (!loadingAuth) load();
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [loadingAuth, page]);

  const onRead = async (id) => {
    setActionLoading(prev => ({ ...prev, [id]: true }));
    await markNotificationRead(id);
    await load();
    setActionLoading(prev => ({ ...prev, [id]: false }));
  };

  const onReplace = async (notifId, carId) => {
    setActionLoading(prev => ({ ...prev, [`replace_${notifId}`]: true }));
    await notificationAction(notifId, { action: "replace", car_id: carId });
    await load();
    alert("Выбор сохранен");
    setActionLoading(prev => ({ ...prev, [`replace_${notifId}`]: false }));
  };

  const onCancel = async (notifId) => {
    setActionLoading(prev => ({ ...prev, [`cancel_${notifId}`]: true }));
    await notificationAction(notifId, { action: "cancel" });
    await load();
    alert("Действие выполнено");
    setActionLoading(prev => ({ ...prev, [`cancel_${notifId}`]: false }));
  };

  if (loadingAuth) return (
    <div style={{
      display: 'flex',
      justifyContent: 'center',
      alignItems: 'center',
      minHeight: '400px',
      fontSize: '18px',
      color: '#64748b'
    }}>
      Проверка авторизации...
    </div>
  );

  return (
    <div className="notifications-container">
      <style>{`
        * {
          margin: 0;
          padding: 0;
          box-sizing: border-box;
          font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, Oxygen, Ubuntu, sans-serif;
        }

        .notifications-container {
          max-width: 1200px;
          margin: 0 auto;
          padding: 20px;
          min-height: 100vh;
          background: #f8fafc;
        }

        .header {
          background: white;
          border-radius: 16px;
          padding: 24px;
          margin-bottom: 24px;
          box-shadow: 0 2px 8px rgba(0, 0, 0, 0.06);
        }

        .header-top {
          display: flex;
          flex-direction: column;
          gap: 16px;
          margin-bottom: 16px;
        }

        @media (min-width: 768px) {
          .header-top {
            flex-direction: row;
            justify-content: space-between;
            align-items: center;
          }
        }

        .title {
          font-size: 28px;
          font-weight: 700;
          color: #1e293b;
          margin: 0;
        }

        .nav-links {
          display: flex;
          gap: 12px;
          flex-wrap: wrap;
        }

        .nav-button {
          padding: 10px 20px;
          background: white;
          border: 2px solid #e2e8f0;
          border-radius: 10px;
          color: #475569;
          text-decoration: none;
          font-weight: 500;
          transition: all 0.2s;
          white-space: nowrap;
          text-align: center;
          font-size: 14px;
        }

        .nav-button:hover {
          background: #f1f5f9;
          border-color: #cbd5e1;
          transform: translateY(-1px);
        }

        .nav-button.primary {
          background: #3b82f6;
          color: white;
          border-color: #3b82f6;
        }

        .nav-button.primary:hover {
          background: #2563eb;
          border-color: #2563eb;
        }

        .message {
          padding: 14px 20px;
          border-radius: 10px;
          margin: 16px 0;
          font-size: 14px;
          display: flex;
          align-items: center;
          gap: 10px;
          animation: slideIn 0.3s ease;
        }

        @keyframes slideIn {
          from {
            opacity: 0;
            transform: translateY(-10px);
          }
          to {
            opacity: 1;
            transform: translateY(0);
          }
        }

        .error {
          background: #fee2e2;
          border: 1px solid #fecaca;
          color: #dc2626;
        }

        .success {
          background: #d1fae5;
          border: 1px solid #a7f3d0;
          color: #065f46;
        }

        .stats-grid {
          display: grid;
          grid-template-columns: repeat(auto-fit, minmax(150px, 1fr));
          gap: 16px;
          margin-top: 24px;
        }

        .stat-card {
          background: white;
          border-radius: 12px;
          padding: 20px;
          text-align: center;
          border: 1px solid #e2e8f0;
        }

        .stat-value {
          font-size: 24px;
          font-weight: 700;
          color: #1e293b;
          margin-bottom: 4px;
        }

        .stat-label {
          font-size: 13px;
          color: #64748b;
          text-transform: uppercase;
          letter-spacing: 0.5px;
        }

        .notifications-list {
          display: grid;
          gap: 16px;
          margin-top: 24px;
        }

        .notification-card {
          background: white;
          border-radius: 16px;
          padding: 24px;
          box-shadow: 0 2px 8px rgba(0, 0, 0, 0.06);
          position: relative;
          transition: all 0.2s ease;
        }

        .notification-card:hover {
          transform: translateY(-2px);
          box-shadow: 0 4px 12px rgba(0, 0, 0, 0.1);
        }

        .notification-card.unread {
          border-left: 4px solid #3b82f6;
        }

        .notification-header {
          display: flex;
          justify-content: space-between;
          align-items: flex-start;
          gap: 16px;
          margin-bottom: 16px;
        }

        .notification-title {
          font-size: 18px;
          font-weight: 600;
          color: #1e293b;
          margin: 0;
          display: flex;
          align-items: center;
          gap: 10px;
        }

        .notification-badge {
          padding: 4px 12px;
          background: #3b82f6;
          color: white;
          border-radius: 20px;
          font-size: 12px;
          font-weight: 600;
          text-transform: uppercase;
          letter-spacing: 0.5px;
        }

        .notification-date {
          font-size: 14px;
          color: #64748b;
          white-space: nowrap;
        }

        .notification-content {
          color: #475569;
          line-height: 1.6;
          margin-bottom: 20px;
        }

        .booking-info {
          background: #f8fafc;
          border-radius: 12px;
          padding: 20px;
          margin: 20px 0;
        }

        .info-grid {
          display: grid;
          grid-template-columns: 1fr;
          gap: 16px;
        }

        @media (min-width: 640px) {
          .info-grid {
            grid-template-columns: 1fr 1fr;
          }
        }

        .info-item {
          display: flex;
          flex-direction: column;
          gap: 8px;
        }

        .info-label {
          font-size: 13px;
          color: #64748b;
          text-transform: uppercase;
          letter-spacing: 0.5px;
          font-weight: 500;
        }

        .info-value {
          font-size: 16px;
          color: #1e293b;
          font-weight: 600;
        }

        .options-grid {
          display: grid;
          grid-template-columns: repeat(auto-fill, minmax(250px, 1fr));
          gap: 12px;
          margin: 20px 0;
        }

        .option-card {
          background: white;
          border: 2px solid #e2e8f0;
          border-radius: 12px;
          padding: 16px;
          cursor: pointer;
          transition: all 0.2s ease;
        }

        .option-card:hover {
          border-color: #3b82f6;
          background: #f8fafc;
          transform: translateY(-2px);
        }

        .option-title {
          font-size: 16px;
          font-weight: 600;
          color: #1e293b;
          margin-bottom: 4px;
        }

        .option-meta {
          font-size: 14px;
          color: #64748b;
        }

        .option-action {
          margin-top: 12px;
          padding: 8px 16px;
          background: #3b82f6;
          color: white;
          border: none;
          border-radius: 8px;
          font-weight: 500;
          cursor: pointer;
          transition: all 0.2s;
          width: 100%;
        }

        .option-action:hover:not(:disabled) {
          background: #2563eb;
        }

        .option-action:disabled {
          background: #cbd5e1;
          cursor: not-allowed;
        }

        .actions-row {
          display: flex;
          gap: 12px;
          margin-top: 24px;
          padding-top: 24px;
          border-top: 1px solid #e2e8f0;
        }

        .action-button {
          padding: 12px 24px;
          border: none;
          border-radius: 10px;
          font-weight: 500;
          cursor: pointer;
          transition: all 0.2s;
          display: flex;
          align-items: center;
          gap: 8px;
          font-size: 14px;
        }

        .action-button.primary {
          background: #10b981;
          color: white;
        }

        .action-button.primary:hover:not(:disabled) {
          background: #059669;
        }

        .action-button.danger {
          background: #ef4444;
          color: white;
        }

        .action-button.danger:hover:not(:disabled) {
          background: #dc2626;
        }

        .action-button.secondary {
          background: #f1f5f9;
          color: #475569;
        }

        .action-button.secondary:hover:not(:disabled) {
          background: #e2e8f0;
        }

        .action-button:disabled {
          opacity: 0.6;
          cursor: not-allowed;
        }

        .empty-state {
          background: white;
          border-radius: 16px;
          padding: 60px 20px;
          text-align: center;
          box-shadow: 0 2px 8px rgba(0, 0, 0, 0.06);
        }

        .empty-icon {
          font-size: 60px;
          color: #cbd5e1;
          margin-bottom: 20px;
        }

        .empty-title {
          font-size: 20px;
          color: #64748b;
          margin-bottom: 8px;
        }

        .empty-text {
          color: #94a3b8;
          font-size: 15px;
        }

        .pagination {
          display: flex;
          justify-content: center;
          align-items: center;
          gap: 12px;
          margin-top: 32px;
          padding-top: 32px;
          border-top: 1px solid #e2e8f0;
        }

        .pagination-button {
          padding: 10px 20px;
          background: white;
          border: 2px solid #e2e8f0;
          border-radius: 10px;
          color: #475569;
          font-weight: 500;
          cursor: pointer;
          transition: all 0.2s;
          min-width: 100px;
          text-align: center;
        }

        .pagination-button:hover:not(:disabled) {
          background: #f1f5f9;
          border-color: #cbd5e1;
        }

        .pagination-button:disabled {
          opacity: 0.5;
          cursor: not-allowed;
        }

        .pagination-info {
          color: #64748b;
          font-size: 14px;
          min-width: 150px;
          text-align: center;
        }

        .info-section {
          background: white;
          border-radius: 16px;
          padding: 24px;
          margin-top: 32px;
          box-shadow: 0 2px 8px rgba(0, 0, 0, 0.06);
        }

        .section-title {
          font-size: 20px;
          font-weight: 600;
          color: #1e293b;
          margin-bottom: 16px;
          display: flex;
          align-items: center;
          gap: 10px;
        }

        .section-title::before {
          content: "?";
          color: #3b82f6;
          font-size: 24px;
        }

        .loading-spinner {
          display: inline-block;
          width: 20px;
          height: 20px;
          border: 2px solid rgba(255,255,255,0.3);
          border-radius: 50%;
          border-top-color: white;
          animation: spin 1s linear infinite;
        }

        @keyframes spin {
          0% { transform: rotate(0deg); }
          100% { transform: rotate(360deg); }
        }

        .mobile-only {
          display: block;
        }

        .desktop-only {
          display: none;
        }

        @media (min-width: 768px) {
          .mobile-only {
            display: none;
          }
          .desktop-only {
            display: block;
          }
        }
      `}</style>

      <header className="header">
        <div className="header-top">
          <h1 className="title">Уведомления</h1>
          <div className="nav-links">
            <Link to="/" className="nav-button">&larr; На главную</Link>
            <Link to="/profile" className="nav-button">Профиль</Link>
            <Link to="/my-bookings" className="nav-button primary">Мои брони</Link>
          </div>
        </div>
        <div className="desktop-only">
          <p style={{ color: '#64748b', fontSize: '15px' }}>
            Все важные обновления по бронированиям и поездкам
          </p>
        </div>
      </header>

      {err && (
        <div className="message error">
          <span style={{ fontSize: '20px' }}>⚠️</span>
          <span>{err}</span>
        </div>
      )}

      {loading ? (
        <div className="empty-state">
          <div className="loading-spinner" style={{ borderColor: '#3b82f6', borderTopColor: '#2563eb', width: '40px', height: '40px', margin: '0 auto 20px' }}></div>
          <div className="empty-title">Загрузка уведомлений...</div>
        </div>
      ) : !data ? null : (
        <>
          {/* Статистика */}
          <div className="stats-grid">
            <div className="stat-card">
              <div className="stat-value">{data.total || 0}</div>
              <div className="stat-label">Всего уведомлений</div>
            </div>
            <div className="stat-card">
              <div className="stat-value">{data.data.filter(n => !n.read_at).length}</div>
              <div className="stat-label">Непрочитанные</div>
            </div>
            <div className="stat-card">
              <div className="stat-value">{data.current_page} / {data.last_page}</div>
              <div className="stat-label">Страница</div>
            </div>
            <div className="stat-card">
              <div className="stat-value">{new Set(data.data.map(n => n.type)).size}</div>
              <div className="stat-label">Типов уведомлений</div>
            </div>
          </div>

          {/* Список уведомлений */}
          <div className="notifications-list">
            {data.data.length === 0 ? (
              <div className="empty-state">
                <div className="empty-icon">📭</div>
                <div className="empty-title">Уведомлений пока нет</div>
                <div className="empty-text">
                  Когда появятся важные обновления по бронированиям, они отобразятся здесь
                </div>
              </div>
            ) : (
              data.data.map((n) => (
                <div 
                  key={n.id} 
                  className={`notification-card ${!n.read_at ? 'unread' : ''}`}
                >
                  <div className="notification-header">
                    <div>
                      <h3 className="notification-title">
                        {n.type === 'booking_affected' ? '🚗' : '🔔'}
                        {n.payload?.title || n.type}
                      </h3>
                      {!n.read_at && (
                        <span className="notification-badge">Новое</span>
                      )}
                    </div>
                    <div className="notification-date">
                      {new Date(n.created_at).toLocaleDateString('ru-RU', {
                        day: 'numeric',
                        month: 'long',
                        year: 'numeric',
                        hour: '2-digit',
                        minute: '2-digit'
                      })}
                    </div>
                  </div>

                  {n.payload?.text && (
                    <div className="notification-content">
                      {n.payload.text}
                    </div>
                  )}

                  {/* Блок замены для брони */}
                  {n.type === "booking_affected" && (
                    <div className="booking-info">
                      <div style={{ marginBottom: '20px' }}>
                        <h4 style={{ 
                          fontSize: '16px', 
                          fontWeight: '600', 
                          color: '#1e293b',
                          marginBottom: '16px'
                        }}>
                          Авто в брони недоступно
                        </h4>
                        
                        <div className="info-grid">
                          <div className="info-item">
                            <div className="info-label">Исходное авто</div>
                            <div className="info-value">{n.payload?.old_car?.name || '-'}</div>
                            <div style={{ fontSize: '14px', color: '#64748b' }}>
                              Класс: {n.payload?.old_car?.class || '-'}
                            </div>
                          </div>

                          <div className="info-item">
                            <div className="info-label">Недоступно до</div>
                            <div className="info-value">{n.payload?.maintenance_until || '-'}</div>
                          </div>
                        </div>
                      </div>

                      {Array.isArray(n.payload?.options) && n.payload.options.length > 0 ? (
                        <div>
                          <p style={{ 
                            fontSize: '15px', 
                            fontWeight: '500', 
                            color: '#475569',
                            marginBottom: '16px'
                          }}>
                            Доступные варианты для замены:
                          </p>
                          
                          <div className="options-grid">
                            {n.payload.options.map((c) => (
                              <div key={c.id} className="option-card">
                                <div className="option-title">{c.name}</div>
                                <div className="option-meta">Класс: {c.class}</div>
                                <button
                                  onClick={() => onReplace(n.id, c.id)}
                                  disabled={actionLoading[`replace_${n.id}`]}
                                  className="option-action"
                                >
                                  {actionLoading[`replace_${n.id}`] ? (
                                    <>
                                      <span className="loading-spinner" style={{ marginRight: '8px' }}></span>
                                      Отправка...
                                    </>
                                  ) : 'Выбрать'}
                                </button>
                              </div>
                            ))}
                          </div>
                        </div>
                      ) : (
                        <div style={{
                          background: '#fee2e2',
                          padding: '16px',
                          borderRadius: '8px',
                          textAlign: 'center',
                          marginTop: '16px'
                        }}>
                          <p style={{ color: '#dc2626', fontWeight: '500' }}>
                            На замену сейчас нет доступных машин
                          </p>
                        </div>
                      )}
                    </div>
                  )}

                  {/* Кнопки действий */}
                  <div className="actions-row">
                    {!n.read_at && (
                      <button
                        onClick={() => onRead(n.id)}
                        disabled={actionLoading[n.id]}
                        className="action-button primary"
                      >
                        {actionLoading[n.id] ? (
                          <>
                            <span className="loading-spinner"></span>
                            Обработка...
                          </>
                        ) : 'Отметить как прочитанное'}
                      </button>
                    )}

                    {n.type === "booking_affected" && (
                      <button
                        onClick={() => onCancel(n.id)}
                        disabled={actionLoading[`cancel_${n.id}`]}
                        className="action-button danger"
                      >
                        {actionLoading[`cancel_${n.id}`] ? (
                          <>
                            <span className="loading-spinner"></span>
                            Отправка...
                          </>
                        ) : 'Отменить бронь'}
                      </button>
                    )}
                  </div>
                </div>
              ))
            )}
          </div>

          {/* Пагинация */}
          {data.last_page > 1 && (
            <div className="pagination">
              <button
                disabled={!data.prev_page_url}
                onClick={() => setPage((p) => Math.max(1, p - 1))}
                className="pagination-button"
              >
                &larr; Назад
              </button>
              
              <div className="pagination-info">
                Страница {data.current_page} из {data.last_page}
              </div>
              
              <button
                disabled={!data.next_page_url}
                onClick={() => setPage((p) => p + 1)}
                className="pagination-button"
              >
                Вперед
              </button>
            </div>
          )}
        </>
      )}

      {/* Инфо-блок */}
      <div className="info-section">
        <h3 className="section-title">Как работают уведомления</h3>
        <p style={{ color: '#475569', lineHeight: '1.6', fontSize: '15px' }}>
          Система автоматически сообщает обо всех важных событиях: изменениях бронирования,
          переносах поездки, подтверждениях и отменах. Проверяйте уведомления регулярно,
          чтобы своевременно принять решение и не потерять актуальную бронь.
        </p>
      </div>
    </div>
  );
}
